#!/usr/bin/bash

bundle exec sass --update --sourcemap=none .
